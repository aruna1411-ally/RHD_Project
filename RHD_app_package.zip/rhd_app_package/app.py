import os
import numpy as np
import pandas as pd
import streamlit as st
import librosa
import matplotlib.pyplot as plt
import tensorflow as tf
from scipy.signal import butter, filtfilt

ROOT = os.path.dirname(os.path.abspath(__file__))
PCG_PATH = os.path.join(ROOT, 'processed', 'PCG', 'best_pcg_cnn_clean.keras')
ECG_PATH = os.path.join(ROOT, 'processed', 'ECG', 'best_ecg_1dcnn_clean.keras')
FUSION_PATH = os.path.join(ROOT, 'processed', 'PCG_ECG_best_attention_fusion_clean.keras')
THRESHOLD = 0.4031

st.set_page_config(page_title='RHD Multimodal Screening', page_icon='❤️', layout='wide')
st.markdown('''<div style="padding:22px;border-radius:16px;background:linear-gradient(120deg,#102a43,#176b87);color:white"><h1 style="color:white;margin:0">❤️ AI-Based RHD Screening Prototype</h1><p style="margin:6px 0 0">ECG + PCG • Attention-based multimodal fusion • Grad-CAM</p></div>''', unsafe_allow_html=True)
st.write('Upload PCG heart-sound audio and an ECG waveform to run the saved models. Research prototype only; not a clinical diagnosis.')

@st.cache_resource(show_spinner='Loading trained models...')
def load_models():
    for p in [PCG_PATH, ECG_PATH, FUSION_PATH]:
        if not os.path.isfile(p):
            raise FileNotFoundError(f'Model not found: {os.path.relpath(p, ROOT)}')
    pcg = tf.keras.models.load_model(PCG_PATH, compile=False)
    ecg = tf.keras.models.load_model(ECG_PATH, compile=False)
    fusion = tf.keras.models.load_model(FUSION_PATH, compile=False)
    # Saved branch models output 64-D embeddings at the penultimate layer.
    pcg_encoder = tf.keras.Model(pcg.input, pcg.layers[-2].output)
    ecg_encoder = tf.keras.Model(ecg.input, ecg.layers[-2].output)
    return pcg, ecg, fusion, pcg_encoder, ecg_encoder

def preprocess_pcg(upload):
    y, sr = librosa.load(upload, sr=None, mono=True)
    if len(y) == 0 or np.max(np.abs(y)) < 1e-8:
        raise ValueError('PCG file is empty or silent.')
    y = y / np.max(np.abs(y))
    n = int(1.2 * sr)
    segments = [y[i:i+n] for i in range(0, len(y)-n+1, n)]
    if not segments:
        raise ValueError('PCG audio must be at least 1.2 seconds long.')
    specs = []
    for seg in segments:
        mel = librosa.feature.melspectrogram(y=seg, sr=sr, n_mels=40, n_fft=256, hop_length=128)
        logmel = librosa.power_to_db(mel, ref=np.max)
        # Model was trained on (40, 19, 1).
        if logmel.shape[1] < 19:
            logmel = np.pad(logmel, ((0, 0), (0, 19-logmel.shape[1])))
        else:
            logmel = logmel[:, :19]
        specs.append(logmel.astype('float32'))
    return np.asarray(specs)[..., None], y, sr

def read_ecg(upload, column=None):
    if upload.name.lower().endswith('.npy'):
        x = np.asarray(np.load(upload, allow_pickle=False), dtype=np.float32).squeeze()
        if x.ndim != 1:
            raise ValueError('ECG .npy file must contain one 1-D waveform.')
        return x
    df = pd.read_csv(upload, header=None, sep=None, engine='python')
    df = df.apply(pd.to_numeric, errors='coerce').dropna(axis=1, how='all')
    if df.empty:
        raise ValueError('No numeric ECG samples were found in the file.')
    if column is None:
        column = df.columns[0]
    return df[column].dropna().to_numpy(dtype=np.float32)

def preprocess_ecg(signal, fs):
    x = np.asarray(signal, dtype=np.float64).reshape(-1)
    x = x[np.isfinite(x)]
    if len(x) < 4000:
        raise ValueError(f'ECG needs at least 4000 samples; received {len(x)}.')
    if fs > 80:
        nyq = fs / 2
        lo, hi = max(0.5/nyq, 0.0001), min(40/nyq, 0.99)
        if lo < hi:
            b, a = butter(3, [lo, hi], btype='bandpass')
            try: x = filtfilt(b, a, x)
            except ValueError: pass
    med = np.median(x)
    mad = np.median(np.abs(x-med))
    scale = 1.4826*mad
    if not np.isfinite(scale) or scale < 1e-8: scale = np.std(x)
    if not np.isfinite(scale) or scale < 1e-8: raise ValueError('ECG signal is flat or invalid.')
    x = (x-med)/scale
    segs = [x[i:i+4000] for i in range(0, len(x)-3999, 4000)]
    return np.asarray(segs, dtype='float32')[..., None], x

def gradcam_plot(model, x, kind):
    convs = [l for l in model.layers if isinstance(l, (tf.keras.layers.Conv1D, tf.keras.layers.Conv2D))]
    if not convs: return None
    try:
        layer = convs[-1]
        gm = tf.keras.Model(model.inputs, [layer.output, model.output])
        with tf.GradientTape() as tape:
            activations, pred = gm(tf.convert_to_tensor(x[:1]), training=False)
            score = pred[:, 0]
        grads = tape.gradient(score, activations)
        if grads is None: return None
        axes = tuple(range(1, len(grads.shape)-1))
        weights = tf.reduce_mean(grads, axis=axes)
        heat = tf.maximum(tf.reduce_sum(activations[0] * weights[0], axis=-1), 0)
        heat = heat / (tf.reduce_max(heat) + 1e-8)
        heat = heat.numpy()
        fig, ax = plt.subplots(figsize=(7, 3))
        if kind == 'PCG':
            base = x[0, :, :, 0]
            ax.imshow(base, aspect='auto', origin='lower', cmap='gray')
            hm = tf.image.resize(heat[..., None], base.shape).numpy().squeeze()
            ax.imshow(hm, aspect='auto', origin='lower', cmap='jet', alpha=.42)
            ax.set(xlabel='Time frames', ylabel='Mel bands', title='PCG Grad-CAM')
        else:
            wave = x[0, :, 0]
            xx = np.arange(len(wave))
            ax.plot(xx, wave, lw=.8)
            hm = tf.image.resize(heat[None, :, None], (len(wave), 1)).numpy().reshape(-1)
            ax.fill_between(xx, wave.min(), wave.min() + hm*(wave.max()-wave.min())*.35, color='red', alpha=.25)
            ax.set(xlabel='Sample index', ylabel='Normalized amplitude', title='ECG Grad-CAM')
        fig.tight_layout()
        return fig
    except Exception:
        return None

try:
    pcg_model, ecg_model, fusion_model, pcg_encoder, ecg_encoder = load_models()
    st.success('Trained PCG, ECG and fusion models loaded.')
except Exception as e:
    st.error(f'Unable to load models: {e}')
    st.info('Keep app.py in the RHD_Project root and preserve the processed/ model folders.')
    st.stop()

with st.sidebar:
    st.header('Upload inputs')
    pcg_file = st.file_uploader('PCG heart sound (.wav)', type=['wav'])
    ecg_file = st.file_uploader('ECG waveform (.csv, .txt, .npy)', type=['csv','txt','npy'])
    fs = st.number_input('ECG sampling rate (Hz)', min_value=100, max_value=10000, value=2000, step=100)
    st.caption('CSV/TXT must contain numeric ECG samples. For CSV with multiple columns, select the signal column below.')

col = None
if ecg_file is not None and not ecg_file.name.lower().endswith('.npy'):
    try:
        tmp = pd.read_csv(ecg_file, header=None, sep=None, engine='python').apply(pd.to_numeric, errors='coerce').dropna(axis=1, how='all')
        if not tmp.empty:
            col = st.selectbox('ECG signal column', list(tmp.columns), format_func=lambda v: f'Column {v}')
    except Exception as e:
        st.error(f'Could not read ECG CSV: {e}')

if st.button('Run multimodal screening', type='primary', use_container_width=True, disabled=(pcg_file is None or ecg_file is None)):
    try:
        with st.spinner('Preprocessing signals and running multimodal fusion...'):
            Xp, pcg_wave, pcg_sr = preprocess_pcg(pcg_file)
            Xe, ecg_wave = preprocess_ecg(read_ecg(ecg_file, col), float(fs))
            # Aggregate segment embeddings to one vector per recording, as in training.
            pf = np.mean(pcg_encoder.predict(Xp, verbose=0), axis=0, keepdims=True)
            ef = np.mean(ecg_encoder.predict(Xe, verbose=0), axis=0, keepdims=True)
            prob = float(np.asarray(fusion_model.predict([pf, ef], verbose=0)).reshape(-1)[0])
            label = 'Abnormal' if prob >= THRESHOLD else 'Normal'
        st.markdown('## Final screening output')
        a,b,c = st.columns(3)
        a.metric('Predicted class', label)
        b.metric('Abnormal probability', f'{prob*100:.1f}%')
        c.metric('Decision threshold', f'{THRESHOLD:.4f}')
        if label == 'Abnormal': st.warning('Model output is Abnormal. Further clinical evaluation is needed; this is not a diagnosis.')
        else: st.info('Model output is Normal. This does not rule out RHD or replace clinical evaluation.')
        st.progress(min(max(prob, 0), 1), text=f'Abnormal score: {prob:.3f}')
        st.markdown('## Explainable AI — Grad-CAM')
        st.caption('These are branch-level ECG/PCG explanations, not a direct explanation of the fusion model. Highlighted areas indicate model-influential regions, not confirmed clinical evidence.')
        left,right = st.columns(2)
        with left:
            st.subheader('PCG heart-sound explanation')
            fig = gradcam_plot(pcg_model, Xp[:1], 'PCG')
            if fig is not None: st.pyplot(fig, use_container_width=True); plt.close(fig)
            else: st.info('Grad-CAM was not available for this input.')
            fig,ax = plt.subplots(figsize=(7,2.2)); ax.plot(np.arange(len(pcg_wave))/pcg_sr, pcg_wave, lw=.7); ax.set(xlabel='Time (s)',ylabel='Normalized amplitude',title='Uploaded PCG waveform'); fig.tight_layout(); st.pyplot(fig); plt.close(fig)
        with right:
            st.subheader('ECG waveform explanation')
            fig = gradcam_plot(ecg_model, Xe[:1], 'ECG')
            if fig is not None: st.pyplot(fig, use_container_width=True); plt.close(fig)
            else: st.info('Grad-CAM was not available for this input.')
            fig,ax = plt.subplots(figsize=(7,2.2)); ax.plot(np.arange(len(ecg_wave))/float(fs), ecg_wave, lw=.7); ax.set(xlabel='Time (s)',ylabel='Robust-normalized amplitude',title='Uploaded ECG waveform'); fig.tight_layout(); st.pyplot(fig); plt.close(fig)
        st.markdown('## Run details')
        st.write({'PCG sample rate (Hz)': int(pcg_sr), 'PCG segments': int(len(Xp)), 'ECG sample rate (Hz)': int(fs), 'ECG segments': int(len(Xe)), 'PCG embedding size': int(pf.shape[-1]), 'ECG embedding size': int(ef.shape[-1])})
    except Exception as e:
        st.error(f'Prediction failed: {type(e).__name__}: {e}')
        st.info('Ensure both files contain valid signals and the ECG sampling rate matches the recording.')
else:
    st.markdown('## Quick steps')
    st.markdown('1. Upload PCG `.wav`.\n2. Upload ECG waveform `.csv`, `.txt`, or `.npy`.\n3. Set the ECG sampling rate correctly.\n4. Click **Run multimodal screening**.\n\nThe app reuses saved models and does not retrain them.')

st.caption('Research prototype only. Not clinically validated and must not be used for diagnosis or treatment decisions.')
